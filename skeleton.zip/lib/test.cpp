#include <stdio.h>
#include "/etc/knitro/include/knitro.h"
 
int main(){
    KTR_new();
    return 0;
}